﻿using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Windows.Media.Animation;

namespace ScreenShot
{
    public partial class MainWindow : Window
    {
        private string saveFolder =
            Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

        private MediaPlayer screenshotSound = new MediaPlayer();

        private bool isPlaceholder = true;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void txtName_GotFocus(object sender, RoutedEventArgs e)
        {
            if (isPlaceholder)
            {
                txtName.Text = "";
                txtName.Foreground = System.Windows.Media.Brushes.Black;
                isPlaceholder = false;
            }
        }

        private void txtName_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                txtName.Text = "Name your screenshot";
                txtName.Foreground = System.Windows.Media.Brushes.Gray;
                isPlaceholder = true;
            }
        }

        private void btnFolder_Click(object sender, RoutedEventArgs e)
        {
            using (System.Windows.Forms.FolderBrowserDialog folderDialog =
                   new System.Windows.Forms.FolderBrowserDialog())
            {
                folderDialog.Description =
                    "Choose where screenshots will be saved";

                folderDialog.SelectedPath = saveFolder;

                if (folderDialog.ShowDialog() ==
                    System.Windows.Forms.DialogResult.OK)
                {
                    saveFolder = folderDialog.SelectedPath;

                    MessageBox.Show(
                        $"Screenshots will now save to:\n\n{saveFolder}",
                        "Save Location");
                }
            }
        }

        private async void ShowScreenshotPreview(string filePath)
        {
            BitmapImage previewImage = new BitmapImage();

            previewImage.BeginInit();
            previewImage.CacheOption = BitmapCacheOption.OnLoad;
            previewImage.UriSource =
                new Uri(filePath, UriKind.Absolute);
            previewImage.EndInit();

            imgPreview.Source = previewImage;

            DoubleAnimation fadeIn = new DoubleAnimation
            {
                From = 0,
                To = 1,
                Duration = TimeSpan.FromMilliseconds(200)
            };

            previewBorder.BeginAnimation(
                OpacityProperty,
                fadeIn);

            await Task.Delay(3000);

            DoubleAnimation fadeOut = new DoubleAnimation
            {
                From = 1,
                To = 0,
                Duration = TimeSpan.FromMilliseconds(500)
            };

            previewBorder.BeginAnimation(
                OpacityProperty,
                fadeOut);
        }

        [DllImport("user32.dll")]
        public static extern int GetSystemMetrics(int nIndex);

        private async void btnScreenshot_Click(
            object sender,
            RoutedEventArgs e)
        {
            screenshotSound.Open(
                new Uri(
                    "Assets/cameraclick.mp3",
                    UriKind.Relative));

            screenshotSound.Position = TimeSpan.Zero;
            screenshotSound.Play();

            this.Hide();

            await Task.Delay(200);

            int screenWidth = GetSystemMetrics(0);
            int screenHeight = GetSystemMetrics(1);

            using (Bitmap screenshot =
                   new Bitmap(screenWidth, screenHeight))
            {
                using (Graphics graphics =
                       Graphics.FromImage(screenshot))
                {
                    graphics.CopyFromScreen(
                        0,
                        0,
                        0,
                        0,
                        new System.Drawing.Size(
                            screenWidth,
                            screenHeight));
                }

                string fileName;

                if (isPlaceholder ||
                    string.IsNullOrWhiteSpace(txtName.Text))
                {
                    fileName =
                        $"Screenshot_{DateTime.Now:yyyy-MM-dd_HH-mm-ss}.png";
                }
                else
                {
                    string customName =
                        txtName.Text.Trim();

                    foreach (char invalidChar in
                             System.IO.Path.GetInvalidFileNameChars())
                    {
                        customName =
                            customName.Replace(
                                invalidChar,
                                '_');
                    }

                    fileName = customName + ".png";
                }

                string filePath =
                    System.IO.Path.Combine(
                        saveFolder,
                        fileName);

                screenshot.Save(
                    filePath,
                    ImageFormat.Png);

                // Reset name box
                txtName.Text = "Name your screenshot";
                txtName.Foreground =
                    System.Windows.Media.Brushes.Gray;

                isPlaceholder = true;

                // Bring Screenshot 9001 back
                this.Show();
                this.Activate();

                // Tell user where it was saved
                MessageBox.Show(
                    $"{fileName} saved to:\n\n{saveFolder}",
                    "Screenshot Saved");

                // Show preview after message is closed
                ShowScreenshotPreview(filePath);
            }
        }
    }
}